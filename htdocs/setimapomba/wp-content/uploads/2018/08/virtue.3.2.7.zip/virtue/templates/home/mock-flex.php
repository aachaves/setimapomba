<div class="sliderclass kad-desktop-slider">
  <div id="imageslider" class="container">
    <div class="flexslider kt-flexslider loading" data-flex-speed="7000" data-flex-anim-speed="400" data-flex-animation="fade" data-flex-auto="true">
        <ul class="slides">
                      <li> 
                        <a href="#" target="_blank" >
                          <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/kt_slide_01.jpg' );?>" width="1170px" height="450px" alt="Example Slider 01" />
                        </a>
                      </li>
                      <li> 
                        <a href="#" target="_blank" >
                          <img src="<?php echo esc_url( get_template_directory_uri() .'/assets/img/kt_slide_02.jpg');?>" width="1170px" height="450px" alt="Example Slider 02"/>
                        </a>
                      </li>
        </ul>
      </div> <!--Flex Slides-->
  </div><!--Container-->
</div><!--sliderclass-->