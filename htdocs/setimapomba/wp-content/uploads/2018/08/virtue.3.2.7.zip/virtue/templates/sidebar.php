<?php
/* Deprecated File - Do not use  */

error_log('Virtue Theme Notice: This notice happens if you have an out of date file in your child theme. Please update your child theme files.');

dynamic_sidebar( virtue_sidebar_id() );